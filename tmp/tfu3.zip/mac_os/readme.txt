TFU has a file called .htusers.php where the users for the internal login are stored.
On a mac this file is hidden by default. Therefore you find a renamed version
in this folder. Please modify the file _htaccess.php to your needs and upload 
it to the server to the tfu folder. Rename the file to .htaccess 

Best,
Michael
www.tinywebgallery.com