<?php
defined('_JEXEC') or die();
jimport( 'joomla.application.component.modeladmin' );
class ReizenIwtModelBestemming extends JModelAdmin {    
    public function getForm($data = array(), $loadData = true) {
    }
}
